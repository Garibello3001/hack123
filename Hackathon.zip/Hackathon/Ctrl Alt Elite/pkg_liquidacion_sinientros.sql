-- =============================================================================
-- ARCHIVO: pkg_liquidacion_sinientros.sql
-- MOTOR OBJETIVO: Oracle Database (PL/SQL Legacy 11g/12c)
-- DOMINIO DE NEGOCIO: Seguros - Liquidacion de Siniestros, Reservas y Coaseguro
-- OBJETIVO: Archivo de prueba para herramientas de migracion automatica de codigo
--           legado (contiene cursores, tipos complejos, SQL dinamico, sobrecarga,
--           transacciones autonomas, BULK COLLECT, FORALL y manejo de excepciones)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. ESTRUCTURAS DE TABLAS BASE (DDL DE CONTEXTO PARA ANALIZADOR SINTACTICO)
-- -----------------------------------------------------------------------------
/*
CREATE TABLE POLIZAS (
    id_poliza            NUMBER(12) PRIMARY KEY,
    numero_poliza        VARCHAR2(30) NOT NULL UNIQUE,
    id_tomador           NUMBER(12) NOT NULL,
    ramo_codigo          VARCHAR2(10) NOT NULL, -- 'AUTO', 'VIDA', 'HOGAR', 'RC'
    fecha_inicio_vig     DATE NOT NULL,
    fecha_fin_vig        DATE NOT NULL,
    valor_asegurado_tot  NUMBER(18,2) NOT NULL,
    pct_coaseguro_cedido NUMBER(5,2) DEFAULT 0,
    estado_poliza        VARCHAR2(15) DEFAULT 'ACTIVA', -- 'ACTIVA', 'SUSPENDIDA', 'CANCELADA'
    moneda_codigo        VARCHAR2(3) DEFAULT 'COP'
);

CREATE TABLE COBERTURAS_POLIZA (
    id_cobertura         NUMBER(12) PRIMARY KEY,
    id_poliza            NUMBER(12) REFERENCES POLIZAS(id_poliza),
    codigo_amparo        VARCHAR2(20) NOT NULL,
    limite_asegurado     NUMBER(18,2) NOT NULL,
    pct_deducible        NUMBER(5,2) DEFAULT 0,
    min_deducible_smmlv  NUMBER(5,2) DEFAULT 0,
    aplica_depreciacion  CHAR(1) DEFAULT 'N',
    activo               CHAR(1) DEFAULT 'S'
);

CREATE TABLE SINIESTROS (
    id_siniestro         NUMBER(15) PRIMARY KEY,
    numero_siniestro     VARCHAR2(35) NOT NULL UNIQUE,
    id_poliza            NUMBER(12) REFERENCES POLIZAS(id_poliza),
    codigo_amparo        VARCHAR2(20) NOT NULL,
    fecha_ocurrencia     DATE NOT NULL,
    fecha_aviso          DATE NOT NULL,
    valor_reclamado      NUMBER(18,2) NOT NULL,
    valor_reserva_actual NUMBER(18,2) NOT NULL,
    valor_indemnizado    NUMBER(18,2) DEFAULT 0,
    estado_siniestro     VARCHAR2(20) DEFAULT 'ABIERTO', -- 'ABIERTO', 'EN_ESTUDIO', 'LIQUIDADO', 'RECHAZADO', 'OBJETADO'
    indicador_fraude     CHAR(1) DEFAULT 'N',
    fecha_liquidacion    DATE,
    usuario_liquidador   VARCHAR2(50)
);

CREATE TABLE LIQUIDACIONES_DETALLE (
    id_liquidacion       NUMBER(15) PRIMARY KEY,
    id_siniestro         NUMBER(15) REFERENCES SINIESTROS(id_siniestro),
    secuencia_pago       NUMBER(4) NOT NULL,
    concepto_codigo      VARCHAR2(20) NOT NULL, -- 'INDEMNIZACION', 'HONORARIOS', 'SALVAMENTO', 'GASTOS_MED'
    valor_bruto          NUMBER(18,2) NOT NULL,
    valor_deducible      NUMBER(18,2) NOT NULL,
    valor_depreciacion   NUMBER(18,2) DEFAULT 0,
    valor_retencion_imp  NUMBER(18,2) DEFAULT 0,
    valor_coaseguro_cia  NUMBER(18,2) NOT NULL,
    valor_neto_pagar     NUMBER(18,2) NOT NULL,
    fecha_calculo        TIMESTAMP DEFAULT SYSTIMESTAMP,
    estado_pago          VARCHAR2(15) DEFAULT 'PENDIENTE'
);

CREATE TABLE PARAMETROS_SISTEMA (
    codigo_parametro     VARCHAR2(40) PRIMARY KEY,
    anio_vigencia        NUMBER(4) NOT NULL,
    valor_numerico       NUMBER(18,4),
    valor_texto          VARCHAR2(200)
);

CREATE TABLE AUDITORIA_LIQUIDACION (
    id_auditoria         NUMBER(18) PRIMARY KEY,
    id_siniestro         NUMBER(15),
    operacion            VARCHAR2(50),
    codigo_error         NUMBER(10),
    mensaje_proceso      VARCHAR2(4000),
    usuario_db           VARCHAR2(50),
    fecha_evento         TIMESTAMP DEFAULT SYSTIMESTAMP
);

CREATE SEQUENCE SEQ_LIQUIDACION_ID START WITH 1000 INCREMENT BY 1;
CREATE SEQUENCE SEQ_AUDITORIA_ID START WITH 1 INCREMENT BY 1;
*/

-- -----------------------------------------------------------------------------
-- 2. ESPECIFICACION DEL PAQUETE (PACKAGE SPECIFICATION)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE pkg_liquidacion_sinientros AS

    -- Constantes globales de negocio
    c_estado_abierto    CONSTANT VARCHAR2(20) := 'ABIERTO';
    c_estado_estudio    CONSTANT VARCHAR2(20) := 'EN_ESTUDIO';
    c_estado_liquidado  CONSTANT VARCHAR2(20) := 'LIQUIDADO';
    c_estado_rechazado  CONSTANT VARCHAR2(20) := 'RECHAZADO';
    c_estado_objetado   CONSTANT VARCHAR2(20) := 'OBJETADO';
    
    c_dias_max_aviso    CONSTANT NUMBER(3)    := 30;
    c_tasa_retefuente   CONSTANT NUMBER(5,4)  := 0.0700; -- 7% retencion indemnizaciones
    c_uvt_min_retencion CONSTANT NUMBER(6)    := 45;

    -- Variables globales con estado (Stateful Package Variables - patron legado critico)
    g_usuario_actual    VARCHAR2(50) := USER;
    g_anio_proceso      NUMBER(4)    := EXTRACT(YEAR FROM SYSDATE);
    g_total_procesados  NUMBER(10)   := 0;
    g_modo_debug        BOOLEAN      := FALSE;

    -- Excepciones personalizadas de negocio
    e_poliza_sin_cobertura  EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_poliza_sin_cobertura, -20001);

    e_siniestro_extemporaneo EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_siniestro_extemporaneo, -20002);

    e_reserva_insuficiente  EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_reserva_insuficiente, -20003);

    e_alerta_fraude_activo  EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_alerta_fraude_activo, -20004);

    e_bloqueo_registro      EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_bloqueo_registro, -54); -- ORA-00054: resource busy

    -- Tipos de datos compuestos (Records y Colecciones PL/SQL)
    TYPE tr_resumen_liquidacion IS RECORD (
        id_siniestro        NUMBER(15),
        numero_siniestro    VARCHAR2(35),
        ramo_codigo         VARCHAR2(10),
        valor_bruto         NUMBER(18,2),
        valor_deducible     NUMBER(18,2),
        valor_depreciacion  NUMBER(18,2),
        valor_impuestos     NUMBER(18,2),
        valor_cargo_coaseg  NUMBER(18,2),
        valor_neto_cia      NUMBER(18,2),
        aprobado_pago       BOOLEAN,
        causal_rechazo      VARCHAR2(250)
    );

    -- Tabla asociativa indexada por entero (Index-by Table)
    TYPE tt_lote_liquidacion IS TABLE OF tr_resumen_liquidacion INDEX BY PLS_INTEGER;

    -- Tabla anidada de IDs para procesamiento batch
    TYPE tt_ids_siniestros IS TABLE OF NUMBER(15);

    -- Cursor de referencia debil para integracion con reportes legados
    TYPE t_ref_cursor IS REF CURSOR;

    -- =========================================================================
    -- FIRMAS DE FUNCIONES Y PROCEDIMIENTOS PUBLICOS
    -- =========================================================================

    -- Obtiene parametro general (SMMLV, UVT, Tasa de cambio)
    FUNCTION fn_obtener_parametro (
        p_codigo_parametro IN VARCHAR2,
        p_anio             IN NUMBER DEFAULT NULL
    ) RETURN NUMBER;

    -- Calcula el deducible aplicable combinando porcentaje y tope minimo en SMMLV
    FUNCTION fn_calcular_deducible (
        p_valor_perdida     IN NUMBER,
        p_pct_deducible     IN NUMBER,
        p_min_smmlv         IN NUMBER,
        p_ramo_codigo       IN VARCHAR2,
        p_fecha_ocurrencia  IN DATE
    ) RETURN NUMBER;

    -- Calcula depreciacion por antiguedad y uso (aplicable a AUTO y HOGAR)
    FUNCTION fn_calcular_depreciacion (
        p_valor_reclamado   IN NUMBER,
        p_fecha_inicio_pol  IN DATE,
        p_fecha_ocurrencia  IN DATE,
        p_aplica_deprec     IN CHAR
    ) RETURN NUMBER;

    -- Liquidacion individual por ID de siniestro (Sobrecarga 1)
    PROCEDURE prc_liquidar_siniestro (
        p_id_siniestro      IN NUMBER,
        p_forzar_aprobacion IN VARCHAR2 DEFAULT 'N',
        p_valor_salvamento  IN NUMBER DEFAULT 0,
        p_resultado         OUT tr_resumen_liquidacion,
        p_codigo_respuesta  OUT NUMBER,
        p_mensaje_respuesta OUT VARCHAR2
    );

    -- Liquidacion individual por Numero de Siniestro (Sobrecarga 2)
    PROCEDURE prc_liquidar_siniestro (
        p_numero_siniestro  IN VARCHAR2,
        p_usuario_ejecutor  IN VARCHAR2,
        p_valor_neto_pagar  OUT NUMBER,
        p_codigo_respuesta  OUT NUMBER,
        p_mensaje_respuesta OUT VARCHAR2
    );

    -- Procesamiento masivo por lote (Batch con BULK COLLECT y FORALL)
    PROCEDURE prc_liquidar_lote_masivo (
        p_ramo_codigo       IN VARCHAR2,
        p_fecha_corte       IN DATE,
        p_limite_registros  IN NUMBER DEFAULT 500,
        p_total_exitosos    OUT NUMBER,
        p_total_fallidos    OUT NUMBER
    );

    -- Consulta dinamica de siniestros para bandeja de auditoria
    PROCEDURE prc_consultar_bandeja_dinamica (
        p_filtro_ramo       IN VARCHAR2 DEFAULT NULL,
        p_monto_minimo      IN NUMBER DEFAULT NULL,
        p_incluir_objetados IN CHAR DEFAULT 'N',
        p_orden_columna     IN VARCHAR2 DEFAULT 'FECHA_OCURRENCIA',
        p_cursor_salida     OUT t_ref_cursor
    );

END pkg_liquidacion_sinientros;
/

-- -----------------------------------------------------------------------------
-- 3. CUERPO DEL PAQUETE (PACKAGE BODY)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE BODY pkg_liquidacion_sinientros AS

    -- Cursor explicito global privado con parametros
    CURSOR c_datos_siniestro (cp_id_siniestro NUMBER) IS
        SELECT s.id_siniestro,
               s.numero_siniestro,
               s.id_poliza,
               s.codigo_amparo,
               s.fecha_ocurrencia,
               s.fecha_aviso,
               s.valor_reclamado,
               s.valor_reserva_actual,
               s.valor_indemnizado,
               s.estado_siniestro,
               s.indicador_fraude,
               p.numero_poliza,
               p.ramo_codigo,
               p.fecha_inicio_vig,
               p.fecha_fin_vig,
               p.valor_asegurado_tot,
               NVL(p.pct_coaseguro_cedido, 0) AS pct_coaseguro_cedido,
               p.estado_poliza,
               c.limite_asegurado,
               NVL(c.pct_deducible, 0)        AS pct_deducible,
               NVL(c.min_deducible_smmlv, 0)  AS min_deducible_smmlv,
               NVL(c.aplica_depreciacion, 'N') AS aplica_depreciacion,
               c.activo                       AS cobertura_activa
          FROM SINIESTROS s
         INNER JOIN POLIZAS p
            ON s.id_poliza = p.id_poliza
          LEFT JOIN COBERTURAS_POLIZA c
            ON c.id_poliza = p.id_poliza
           AND c.codigo_amparo = s.codigo_amparo
         WHERE s.id_siniestro = cp_id_siniestro;

    -- =========================================================================
    -- PROCEDIMIENTO PRIVADO: Registro de auditoria en transaccion autonoma
    -- =========================================================================
    PROCEDURE prc_registrar_auditoria (
        p_id_siniestro  IN NUMBER,
        p_operacion     IN VARCHAR2,
        p_codigo_error  IN NUMBER,
        p_mensaje       IN VARCHAR2
    ) IS
        PRAGMA AUTONOMOUS_TRANSACTION;
        v_mensaje_recortado VARCHAR2(4000);
    BEGIN
        v_mensaje_recortado := SUBSTR(p_mensaje, 1, 4000);

        INSERT INTO AUDITORIA_LIQUIDACION (
            id_auditoria,
            id_siniestro,
            operacion,
            codigo_error,
            mensaje_proceso,
            usuario_db,
            fecha_evento
        ) VALUES (
            SEQ_AUDITORIA_ID.NEXTVAL,
            p_id_siniestro,
            p_operacion,
            p_codigo_error,
            v_mensaje_recortado,
            NVL(g_usuario_actual, USER),
            SYSTIMESTAMP
        );

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK; -- Evita que un fallo en log detenga el flujo principal
    END prc_registrar_auditoria;

    -- =========================================================================
    -- FUNCION PUBLICA: fn_obtener_parametro
    -- =========================================================================
    FUNCTION fn_obtener_parametro (
        p_codigo_parametro IN VARCHAR2,
        p_anio             IN NUMBER DEFAULT NULL
    ) RETURN NUMBER IS
        v_valor NUMBER(18,4);
        v_anio  NUMBER(4);
    BEGIN
        v_anio := NVL(p_anio, g_anio_proceso);

        SELECT valor_numerico
          INTO v_valor
          FROM PARAMETROS_SISTEMA
         WHERE codigo_parametro = UPPER(TRIM(p_codigo_parametro))
           AND anio_vigencia = v_anio;

        RETURN v_valor;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- Valores por defecto de contingencia (Fallback legado)
            IF UPPER(p_codigo_parametro) = 'SMMLV' THEN
                RETURN 1300000;
            ELSIF UPPER(p_codigo_parametro) = 'UVT' THEN
                RETURN 47065;
            ELSE
                RETURN 0;
            END IF;
        WHEN TOO_MANY_ROWS THEN
            SELECT MAX(valor_numerico)
              INTO v_valor
              FROM PARAMETROS_SISTEMA
             WHERE codigo_parametro = UPPER(TRIM(p_codigo_parametro))
               AND anio_vigencia = v_anio;
            RETURN v_valor;
    END fn_obtener_parametro;

    -- =========================================================================
    -- FUNCION PUBLICA: fn_calcular_deducible
    -- =========================================================================
    FUNCTION fn_calcular_deducible (
        p_valor_perdida     IN NUMBER,
        p_pct_deducible     IN NUMBER,
        p_min_smmlv         IN NUMBER,
        p_ramo_codigo       IN VARCHAR2,
        p_fecha_ocurrencia  IN DATE
    ) RETURN NUMBER IS
        v_anio_siniestro    NUMBER(4);
        v_valor_smmlv       NUMBER(18,2);
        v_deducible_pct     NUMBER(18,2);
        v_deducible_min     NUMBER(18,2);
        v_deducible_final   NUMBER(18,2);
    BEGIN
        IF NVL(p_valor_perdida, 0) <= 0 THEN
            RETURN 0;
        END IF;

        v_anio_siniestro  := EXTRACT(YEAR FROM NVL(p_fecha_ocurrencia, SYSDATE));
        v_valor_smmlv     := fn_obtener_parametro('SMMLV', v_anio_siniestro);

        v_deducible_pct   := ROUND(p_valor_perdida * (NVL(p_pct_deducible, 0) / 100), 2);
        v_deducible_min   := ROUND(NVL(p_min_smmlv, 0) * v_valor_smmlv, 2);

        -- Se aplica el mayor entre el porcentaje de la perdida y los SMMLV minimos
        v_deducible_final := GREATEST(v_deducible_pct, v_deducible_min);

        -- Regla especial legada para ramo VIDA: sin deducible en muerte accidental
        IF p_ramo_codigo = 'VIDA' AND p_pct_deducible = 0 THEN
            v_deducible_final := 0;
        END IF;

        -- El deducible nunca puede superar el valor mismo de la perdida
        IF v_deducible_final > p_valor_perdida THEN
            v_deducible_final := p_valor_perdida;
        END IF;

        RETURN v_deducible_final;
    END fn_calcular_deducible;

    -- =========================================================================
    -- FUNCION PUBLICA: fn_calcular_depreciacion
    -- =========================================================================
    FUNCTION fn_calcular_depreciacion (
        p_valor_reclamado   IN NUMBER,
        p_fecha_inicio_pol  IN DATE,
        p_fecha_ocurrencia  IN DATE,
        p_aplica_deprec     IN CHAR
    ) RETURN NUMBER IS
        v_meses_transcurridos NUMBER(10,2);
        v_tasa_mensual        NUMBER(6,4) := 0.0085; -- 0.85% mensual
        v_pct_acumulado       NUMBER(6,4);
    BEGIN
        IF NVL(p_aplica_deprec, 'N') <> 'S' OR p_valor_reclamado <= 0 THEN
            RETURN 0;
        END IF;

        v_meses_transcurridos := MONTHS_BETWEEN(TRUNC(p_fecha_ocurrencia), TRUNC(p_fecha_inicio_pol));

        IF v_meses_transcurridos <= 6 THEN
            RETURN 0; -- Carencia de depreciacion durante los primeros 6 meses
        END IF;

        v_pct_acumulado := (v_meses_transcurridos - 6) * v_tasa_mensual;

        -- Tope maximo de demerito o depreciacion: 35%
        IF v_pct_acumulado > 0.35 THEN
            v_pct_acumulado := 0.35;
        END IF;

        RETURN ROUND(p_valor_reclamado * v_pct_acumulado, 2);
    END fn_calcular_depreciacion;

    -- =========================================================================
    -- FUNCION PRIVADA: Validacion integral de reglas de negocio
    -- =========================================================================
    FUNCTION fn_validar_reglas_cobertura (
        p_reg_siniestro     IN c_datos_siniestro%ROWTYPE,
        p_forzar_aprobacion IN VARCHAR2,
        p_causal_error      OUT VARCHAR2
    ) RETURN BOOLEAN IS
        v_dias_aviso NUMBER(6);
    BEGIN
        p_causal_error := NULL;

        -- 1. Validacion de alerta de fraude
        IF p_reg_siniestro.indicador_fraude = 'S' AND NVL(p_forzar_aprobacion, 'N') <> 'S' THEN
            p_causal_error := 'Siniestro marcado con alerta de fraude activa.';
            RAISE e_alerta_fraude_activo;
        END IF;

        -- 2. Validacion de estado de poliza y vigencia
        IF p_reg_siniestro.estado_poliza <> 'ACTIVA' THEN
            p_causal_error := 'La poliza ' || p_reg_siniestro.numero_poliza || ' se encuentra en estado ' || p_reg_siniestro.estado_poliza;
            RAISE e_poliza_sin_cobertura;
        END IF;

        IF TRUNC(p_reg_siniestro.fecha_ocurrencia) NOT BETWEEN TRUNC(p_reg_siniestro.fecha_inicio_vig) AND TRUNC(p_reg_siniestro.fecha_fin_vig) THEN
            p_causal_error := 'Fecha de ocurrencia fuera del rango de vigencia de la poliza.';
            RAISE e_poliza_sin_cobertura;
        END IF;

        -- 3. Validacion de existencia y estado del amparo
        IF p_reg_siniestro.cobertura_activa IS NULL OR p_reg_siniestro.cobertura_activa <> 'S' THEN
            p_causal_error := 'El amparo ' || p_reg_siniestro.codigo_amparo || ' no esta contratado o activo.';
            RAISE e_poliza_sin_cobertura;
        END IF;

        -- 4. Validacion de extemporaneidad en el aviso
        v_dias_aviso := TRUNC(p_reg_siniestro.fecha_aviso) - TRUNC(p_reg_siniestro.fecha_ocurrencia);
        IF v_dias_aviso > c_dias_max_aviso AND NVL(p_forzar_aprobacion, 'N') <> 'S' THEN
            p_causal_error := 'Aviso extemporaneo (' || v_dias_aviso || ' dias). Supera maximo de ' || c_dias_max_aviso || ' dias.';
            RAISE e_siniestro_extemporaneo;
        END IF;

        RETURN TRUE;
    END fn_validar_reglas_cobertura;

    -- =========================================================================
    -- PROCEDIMIENTO PUBLICO (Sobrecarga 1): Liquidacion por ID
    -- =========================================================================
    PROCEDURE prc_liquidar_siniestro (
        p_id_siniestro      IN NUMBER,
        p_forzar_aprobacion IN VARCHAR2 DEFAULT 'N',
        p_valor_salvamento  IN NUMBER DEFAULT 0,
        p_resultado         OUT tr_resumen_liquidacion,
        p_codigo_respuesta  OUT NUMBER,
        p_mensaje_respuesta OUT VARCHAR2
    ) IS
        v_reg_sin           c_datos_siniestro%ROWTYPE;
        v_bloqueo_dummy     NUMBER(15);
        v_causal_rechazo    VARCHAR2(250);
        v_es_valido         BOOLEAN;
        v_base_indemnizable NUMBER(18,2);
        v_subtotal_indem    NUMBER(18,2);
        v_valor_uvt         NUMBER(18,2);
        v_tope_retencion    NUMBER(18,2);
        v_secuencia_sig     NUMBER(4);
    BEGIN
        p_codigo_respuesta  := 0;
        p_mensaje_respuesta := 'Liquidacion procesada exitosamente.';

        SAVEPOINT sp_inicio_liquidacion;

        -- Apertura de cursor explicito para lectura de contexto
        OPEN c_datos_siniestro(p_id_siniestro);
        FETCH c_datos_siniestro INTO v_reg_sin;

        IF c_datos_siniestro%NOTFOUND THEN
            CLOSE c_datos_siniestro;
            p_codigo_respuesta  := 404;
            p_mensaje_respuesta := 'No existe el siniestro con ID: ' || p_id_siniestro;
            RETURN;
        END IF;
        CLOSE c_datos_siniestro;

        -- Inicializacion de estructura record de salida
        p_resultado.id_siniestro     := v_reg_sin.id_siniestro;
        p_resultado.numero_siniestro := v_reg_sin.numero_siniestro;
        p_resultado.ramo_codigo      := v_reg_sin.ramo_codigo;
        p_resultado.aprobado_pago    := FALSE;

        -- Validar que el siniestro este en estado procesable
        IF v_reg_sin.estado_siniestro NOT IN (c_estado_abierto, c_estado_estudio) THEN
            p_codigo_respuesta  := 101;
            p_mensaje_respuesta := 'Estado invalido para liquidar: ' || v_reg_sin.estado_siniestro;
            RETURN;
        END IF;

        -- Bloqueo pesimista del registro antes de modificar (NOWAIT)
        SELECT id_siniestro
          INTO v_bloqueo_dummy
          FROM SINIESTROS
         WHERE id_siniestro = p_id_siniestro
           FOR UPDATE NOWAIT;

        -- Validacion de reglas de negocio (puede disparar excepciones de negocio)
        v_es_valido := fn_validar_reglas_cobertura(
            p_reg_siniestro     => v_reg_sin,
            p_forzar_aprobacion => p_forzar_aprobacion,
            p_causal_error      => v_causal_rechazo
        );

        -- 1. Determinar valor bruto sujeto a limite asegurado del amparo
        v_base_indemnizable := LEAST(v_reg_sin.valor_reclamado, v_reg_sin.limite_asegurado);
        p_resultado.valor_bruto := v_base_indemnizable;

        -- 2. Calcular depreciacion y deducible
        p_resultado.valor_depreciacion := fn_calcular_depreciacion(
            p_valor_reclamado  => v_base_indemnizable,
            p_fecha_inicio_pol => v_reg_sin.fecha_inicio_vig,
            p_fecha_ocurrencia => v_reg_sin.fecha_ocurrencia,
            p_aplica_deprec    => v_reg_sin.aplica_depreciacion
        );

        p_resultado.valor_deducible := fn_calcular_deducible(
            p_valor_perdida    => v_base_indemnizable - p_resultado.valor_depreciacion,
            p_pct_deducible    => v_reg_sin.pct_deducible,
            p_min_smmlv        => v_reg_sin.min_deducible_smmlv,
            p_ramo_codigo      => v_reg_sin.ramo_codigo,
            p_fecha_ocurrencia => v_reg_sin.fecha_ocurrencia
        );

        -- 3. Descontar salvamento si aplica
        v_subtotal_indem := GREATEST(
            0,
            v_base_indemnizable - p_resultado.valor_depreciacion - p_resultado.valor_deducible - NVL(p_valor_salvamento, 0)
        );

        -- 4. Validar suficiencia de reserva tecnica
        IF v_subtotal_indem > v_reg_sin.valor_reserva_actual AND NVL(p_forzar_aprobacion, 'N') <> 'S' THEN
            v_causal_rechazo := 'Monto calculado (' || v_subtotal_indem || ') supera reserva constituida (' || v_reg_sin.valor_reserva_actual || ').';
            RAISE e_reserva_insuficiente;
        END IF;

        -- 5. Calculo de retencion tributaria (aplica para ramos patrimoniales sobre tope UVT)
        v_valor_uvt      := fn_obtener_parametro('UVT', EXTRACT(YEAR FROM SYSDATE));
        v_tope_retencion := c_uvt_min_retencion * v_valor_uvt;

        IF v_reg_sin.ramo_codigo <> 'VIDA' AND v_subtotal_indem >= v_tope_retencion THEN
            p_resultado.valor_impuestos := ROUND(v_subtotal_indem * c_tasa_retefuente, 2);
        ELSE
            p_resultado.valor_impuestos := 0;
        END IF;

        -- 6. Reparto por Coaseguro Cedido
        p_resultado.valor_cargo_coaseg := ROUND(v_subtotal_indem * (v_reg_sin.pct_coaseguro_cedido / 100), 2);
        p_resultado.valor_neto_cia     := ROUND((v_subtotal_indem - p_resultado.valor_cargo_coaseg) - p_resultado.valor_impuestos, 2);
        p_resultado.aprobado_pago      := TRUE;

        -- 7. Calcular siguiente secuencia de detalle
        SELECT NVL(MAX(secuencia_pago), 0) + 1
          INTO v_secuencia_sig
          FROM LIQUIDACIONES_DETALLE
         WHERE id_siniestro = p_id_siniestro;

        -- 8. Insertar registro en detalle de liquidacion
        INSERT INTO LIQUIDACIONES_DETALLE (
            id_liquidacion,
            id_siniestro,
            secuencia_pago,
            concepto_codigo,
            valor_bruto,
            valor_deducible,
            valor_depreciacion,
            valor_retencion_imp,
            valor_coaseguro_cia,
            valor_neto_pagar,
            fecha_calculo,
            estado_pago
        ) VALUES (
            SEQ_LIQUIDACION_ID.NEXTVAL,
            p_id_siniestro,
            v_secuencia_sig,
            'INDEMNIZACION',
            p_resultado.valor_bruto,
            p_resultado.valor_deducible,
            p_resultado.valor_depreciacion,
            p_resultado.valor_impuestos,
            p_resultado.valor_cargo_coaseg,
            p_resultado.valor_neto_cia,
            SYSTIMESTAMP,
            DECODE(p_resultado.valor_neto_cia, 0, 'SIN_PAGO', 'PENDIENTE')
        );

        -- 9. Actualizar cabecera del siniestro
        UPDATE SINIESTROS
           SET valor_indemnizado    = NVL(valor_indemnizado, 0) + p_resultado.valor_neto_cia,
               valor_reserva_actual = 0,
               estado_siniestro     = c_estado_liquidado,
               fecha_liquidacion    = SYSDATE,
               usuario_liquidador   = g_usuario_actual
         WHERE id_siniestro = p_id_siniestro;

        g_total_procesados := g_total_procesados + 1;

        prc_registrar_auditoria(
            p_id_siniestro => p_id_siniestro,
            p_operacion    => 'LIQUIDACION_EXITOSA',
            p_codigo_error => 0,
            p_mensaje      => 'Siniestro liquidado por valor neto: ' || p_resultado.valor_neto_cia
        );

    EXCEPTION
        WHEN e_poliza_sin_cobertura OR e_siniestro_extemporaneo THEN
            ROLLBACK TO sp_inicio_liquidacion;
            p_resultado.aprobado_pago  := FALSE;
            p_resultado.causal_rechazo := v_causal_rechazo;
            p_codigo_respuesta         := SQLCODE;
            p_mensaje_respuesta        := v_causal_rechazo;

            UPDATE SINIESTROS
               SET estado_siniestro   = c_estado_objetado,
                   usuario_liquidador = g_usuario_actual
             WHERE id_siniestro = p_id_siniestro;

            prc_registrar_auditoria(p_id_siniestro, 'OBJECION_AUTOMATICA', SQLCODE, v_causal_rechazo);

        WHEN e_alerta_fraude_activo OR e_reserva_insuficiente THEN
            ROLLBACK TO sp_inicio_liquidacion;
            p_resultado.aprobado_pago  := FALSE;
            p_resultado.causal_rechazo := v_causal_rechazo;
            p_codigo_respuesta         := SQLCODE;
            p_mensaje_respuesta        := v_causal_rechazo;

            prc_registrar_auditoria(p_id_siniestro, 'BLOQUEO_REGLA_NEGOCIO', SQLCODE, v_causal_rechazo);

        WHEN e_bloqueo_registro THEN
            ROLLBACK TO sp_inicio_liquidacion;
            p_codigo_respuesta  := -54;
            p_mensaje_respuesta := 'El siniestro esta siendo modificado por otro usuario en este momento.';
            prc_registrar_auditoria(p_id_siniestro, 'LOCK_CONCURRENCIA', SQLCODE, SQLERRM);

        WHEN OTHERS THEN
            IF c_datos_siniestro%ISOPEN THEN
                CLOSE c_datos_siniestro;
            END IF;
            ROLLBACK TO sp_inicio_liquidacion;
            p_codigo_respuesta  := SQLCODE;
            p_mensaje_respuesta := 'Error inesperado en liquidacion: ' || SQLERRM;
            prc_registrar_auditoria(p_id_siniestro, 'ERROR_CRITICO', SQLCODE, SQLERRM || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END prc_liquidar_siniestro;

    -- =========================================================================
    -- PROCEDIMIENTO PUBLICO (Sobrecarga 2): Liquidacion por Numero Siniestro
    -- =========================================================================
    PROCEDURE prc_liquidar_siniestro (
        p_numero_siniestro  IN VARCHAR2,
        p_usuario_ejecutor  IN VARCHAR2,
        p_valor_neto_pagar  OUT NUMBER,
        p_codigo_respuesta  OUT NUMBER,
        p_mensaje_respuesta OUT VARCHAR2
    ) IS
        v_id_siniestro NUMBER(15);
        v_resumen      tr_resumen_liquidacion;
    BEGIN
        g_usuario_actual := NVL(TRIM(p_usuario_ejecutor), USER);

        SELECT id_siniestro
          INTO v_id_siniestro
          FROM SINIESTROS
         WHERE numero_siniestro = TRIM(p_numero_siniestro);

        -- Invoca la sobrecarga principal por ID
        prc_liquidar_siniestro(
            p_id_siniestro      => v_id_siniestro,
            p_forzar_aprobacion => 'N',
            p_valor_salvamento  => 0,
            p_resultado         => v_resumen,
            p_codigo_respuesta  => p_codigo_respuesta,
            p_mensaje_respuesta => p_mensaje_respuesta
        );

        p_valor_neto_pagar := NVL(v_resumen.valor_neto_cia, 0);

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_valor_neto_pagar  := 0;
            p_codigo_respuesta  := 404;
            p_mensaje_respuesta := 'No se encontro el numero de siniestro: ' || p_numero_siniestro;
    END prc_liquidar_siniestro;

    -- =========================================================================
    -- PROCEDIMIENTO PUBLICO: Procesamiento Masivo por Lote
    -- =========================================================================
    PROCEDURE prc_liquidar_lote_masivo (
        p_ramo_codigo       IN VARCHAR2,
        p_fecha_corte       IN DATE,
        p_limite_registros  IN NUMBER DEFAULT 500,
        p_total_exitosos    OUT NUMBER,
        p_total_fallidos    OUT NUMBER
    ) IS
        CURSOR c_candidatos IS
            SELECT s.id_siniestro
              FROM SINIESTROS s
             INNER JOIN POLIZAS p
                ON s.id_poliza = p.id_poliza
             WHERE p.ramo_codigo = NVL(p_ramo_codigo, p.ramo_codigo)
               AND s.estado_siniestro = c_estado_abierto
               AND s.indicador_fraude = 'N'
               AND TRUNC(s.fecha_aviso) <= TRUNC(NVL(p_fecha_corte, SYSDATE))
             ORDER BY s.fecha_aviso ASC;

        v_lista_ids      tt_ids_siniestros;
        v_ids_auditoria  tt_ids_siniestros := tt_ids_siniestros();
        v_resumen_indiv  tr_resumen_liquidacion;
        v_cod_resp       NUMBER;
        v_msg_resp       VARCHAR2(4000);
    BEGIN
        p_total_exitosos := 0;
        p_total_fallidos := 0;

        OPEN c_candidatos;
        LOOP
            FETCH c_candidatos
            BULK COLLECT INTO v_lista_ids LIMIT NVL(p_limite_registros, 500);

            EXIT WHEN v_lista_ids.COUNT = 0;

            FOR i IN 1 .. v_lista_ids.COUNT LOOP
                prc_liquidar_siniestro(
                    p_id_siniestro      => v_lista_ids(i),
                    p_forzar_aprobacion => 'N',
                    p_valor_salvamento  => 0,
                    p_resultado         => v_resumen_indiv,
                    p_codigo_respuesta  => v_cod_resp,
                    p_mensaje_respuesta => v_msg_resp
                );

                IF v_cod_resp = 0 AND v_resumen_indiv.aprobado_pago THEN
                    p_total_exitosos := p_total_exitosos + 1;
                    v_ids_auditoria.EXTEND;
                    v_ids_auditoria(v_ids_auditoria.LAST) := v_lista_ids(i);
                ELSE
                    p_total_fallidos := p_total_fallidos + 1;
                END IF;
            END LOOP;

            -- Ejemplo de FORALL con SAVE EXCEPTIONS para actualizacion masiva complementaria
            BEGIN
                FORALL idx IN 1 .. v_ids_auditoria.COUNT SAVE EXCEPTIONS
                    INSERT INTO AUDITORIA_LIQUIDACION (
                        id_auditoria,
                        id_siniestro,
                        operacion,
                        codigo_error,
                        mensaje_proceso,
                        usuario_db,
                        fecha_evento
                    ) VALUES (
                        SEQ_AUDITORIA_ID.NEXTVAL,
                        v_ids_auditoria(idx),
                        'CIERRE_LOTE_BATCH',
                        0,
                        'Confirmado en ejecucion masiva del ramo ' || NVL(p_ramo_codigo, 'TODOS'),
                        g_usuario_actual,
                        SYSTIMESTAMP
                    );
            EXCEPTION
                WHEN OTHERS THEN
                    IF SQLCODE = -24381 THEN -- ORA-24381: error(s) in array DML
                        FOR err_idx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
                            prc_registrar_auditoria(
                                p_id_siniestro => NULL,
                                p_operacion    => 'ERROR_FORALL_BATCH',
                                p_codigo_error => SQL%BULK_EXCEPTIONS(err_idx).ERROR_CODE,
                                p_mensaje      => 'Fallo en indice ' || SQL%BULK_EXCEPTIONS(err_idx).ERROR_INDEX
                            );
                        END LOOP;
                    END IF;
            END;

            v_ids_auditoria.DELETE;
            COMMIT;
        END LOOP;

        CLOSE c_candidatos;
    EXCEPTION
        WHEN OTHERS THEN
            IF c_candidatos%ISOPEN THEN
                CLOSE c_candidatos;
            END IF;
            ROLLBACK;
            RAISE;
    END prc_liquidar_lote_masivo;

    -- =========================================================================
    -- PROCEDIMIENTO PUBLICO: Consulta Dinamica con REF CURSOR y SQL Dinamico
    -- =========================================================================
    PROCEDURE prc_consultar_bandeja_dinamica (
        p_filtro_ramo       IN VARCHAR2 DEFAULT NULL,
        p_monto_minimo      IN NUMBER DEFAULT NULL,
        p_incluir_objetados IN CHAR DEFAULT 'N',
        p_orden_columna     IN VARCHAR2 DEFAULT 'FECHA_OCURRENCIA',
        p_cursor_salida     OUT t_ref_cursor
    ) IS
        v_sql_query     VARCHAR2(4000);
        v_columna_orden VARCHAR2(30);
    BEGIN
        -- Sanitizacion basica de columna de ordenamiento para SQL dinamico
        v_columna_orden := CASE UPPER(TRIM(p_orden_columna))
                               WHEN 'VALOR_RECLAMADO' THEN 's.valor_reclamado DESC'
                               WHEN 'NUMERO_SINIESTRO' THEN 's.numero_siniestro ASC'
                               ELSE 's.fecha_ocurrencia DESC'
                           END;

        v_sql_query := 'SELECT s.id_siniestro, '
                    || '       s.numero_siniestro, '
                    || '       p.numero_poliza, '
                    || '       p.ramo_codigo, '
                    || '       s.fecha_ocurrencia, '
                    || '       s.valor_reclamado, '
                    || '       s.valor_reserva_actual, '
                    || '       s.estado_siniestro, '
                    || '       RANK() OVER (PARTITION BY p.ramo_codigo ORDER BY s.valor_reclamado DESC) AS ranking_severidad '
                    || '  FROM SINIESTROS s '
                    || ' INNER JOIN POLIZAS p ON s.id_poliza = p.id_poliza '
                    || ' WHERE (:b_ramo IS NULL OR p.ramo_codigo = :b_ramo) '
                    || '   AND (:b_monto IS NULL OR s.valor_reclamado >= :b_monto) ';

        IF NVL(p_incluir_objetados, 'N') = 'S' THEN
            v_sql_query := v_sql_query || ' AND s.estado_siniestro IN (''ABIERTO'', ''EN_ESTUDIO'', ''OBJETADO'') ';
        ELSE
            v_sql_query := v_sql_query || ' AND s.estado_siniestro IN (''ABIERTO'', ''EN_ESTUDIO'') ';
        END IF;

        v_sql_query := v_sql_query || ' ORDER BY ' || v_columna_orden;

        OPEN p_cursor_salida FOR v_sql_query
            USING p_filtro_ramo, p_filtro_ramo, p_monto_minimo, p_monto_minimo;

    EXCEPTION
        WHEN OTHERS THEN
            prc_registrar_auditoria(
                p_id_siniestro => NULL,
                p_operacion    => 'ERROR_SQL_DINAMICO',
                p_codigo_error => SQLCODE,
                p_mensaje      => SQLERRM
            );
            RAISE;
    END prc_consultar_bandeja_dinamica;

END pkg_liquidacion_sinientros;
/
